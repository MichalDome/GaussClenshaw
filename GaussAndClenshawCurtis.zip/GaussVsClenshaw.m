
f = cheb.gallerytrig('AMSignal');
fc = chebfun(f, [-1,1]);
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';

% Create a figure and split it into 2 subplots (1 row, 2 columns)
figure

% First subplot: plot of the function f
subplot(2, 1, 1)
plot(fc, LW, 1.2)
title('Funkce f', FS, 16)

% Compute the exact value of the integral
format long
Ichebfun = sum(fc);

% Prepare for error calculations
errg = [];
errc = [];
NN = 5:5:100;

% Loop over different numbers of points
tic
for Npts = NN
  [s1, w1] = legpts(Npts);
  Igauss = w1 * fc(s1);
  errg = [errg abs(Igauss - Ichebfun)];
end
toc
NN = 5:5:100;
tic
for Npts = NN
  [s2, w2] = chebpts(Npts);
  Iclensaw = w2 * fc(s2);
  errc = [errc abs(Iclensaw - Ichebfun)];
end
toc
% Second subplot: semilogy plot of the errors
subplot(2, 1, 2)
semilogy(NN, errg, '.-', LW, 1, MS, 16)
hold on
semilogy(NN, errc, '.-', LW, 1, MS, 16)
grid on
ylim([1e-18 1])
xlabel('počet uzlů', FS, 12)
ylabel('chyba výpočtu', FS, 12)
title('Gauss vs Clenshaw-Curtis', FS, 16)
legend('chyba Gauss', 'chyba CC')