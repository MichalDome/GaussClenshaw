x = chebfun('x');
%f = @(x) x.*sin(3*exp(3*sin(3*exp(3*x))));
%fc = chebfun(f);
f = cheb.gallery('jitter');
fc = chebfun(f, [-1,1]);
length(fc)

LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
%figure, plot(fc,LW,1.2)
%title('Funkce f',FS,16)
format long
Ichebfun = sum(fc);

t = cputime;
%tic;
errimpl = [];
errexpl = [];
NN = 10000:10000:40000;
tic
for Npts = NN
  [s2,w2] = chebpts(Npts);
  Iclensaw = w2*f(s2);
  errimpl = [errimpl abs(Iclensaw-Ichebfun)];
end
toc

tic
for Npts = NN  
  s2 = chebpts(Npts);
  w1=vahyexplicit(Npts-1);
  Iexpl = dot(w1,f(s2));
  errexpl = [errexpl abs(Iexpl-Ichebfun)];
end
toc

fprintf('time = %g\n',  cputime-t);

figure,
semilogy(NN,errimpl,'.-',LW,1,MS,16), grid on
ylim([1e-18 1])
xlabel('počet uzlů',FS,12), ylabel('chyba výpočtu',FS,12)
title('Fast Fourier Transform vs explicitní výpočet vah',FS,16), 
hold on
semilogy(NN, errexpl,'.-',LW,1,MS,16)
legend('FFT','explicit')