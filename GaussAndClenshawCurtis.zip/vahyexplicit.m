function w = vahyexplicit(n)
    % Computes Clenshaw-Curtis weights explicitly based on the given formula.
    % Inputs:
    %   n - Number of intervals (n+1 nodes)
    % Outputs:
    %   w - Weights for Clenshaw-Curtis quadrature

    % Initialize weights
    w = zeros(n+1, 1);

    % Loop over each node
    for k = 0:n
        % Compute ak
        if k == 0 || k == n
            ak = 1; % Boundary nodes
        else
            ak = 2; % Internal nodes
        end

        % Initialize summation
        sum_term = 0;

        %
        %   j = 1:1:floor(n/2);
        %   y = 1./(4*j.^2-1);
        %   c = cos(2*j*k*pi/n);
        %
        for j = 1:floor(n/2)
            % Compute bj
            if j == n/2 && mod(n, 2) == 0 % Only for even n
                bj = 1;
            else
                bj = 2;
            end

            % Summation term
            sum_term = sum_term + (bj / (4*j^2 - 1)) * cos(2*j*k*pi/n);
        end

        % Compute the weight
        w(k+1) = (ak / n) * (1 - sum_term);
    end
end
