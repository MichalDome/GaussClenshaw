x = chebfun('x');
f = cheb.gallerytrig('FMSignal');
fc = chebfun(f, [-1,1]);
LW = 'linewidth'; FS = 'fontsize'; MS = 'markersize';
format long
Ichebfun = sum(fc);

subplot(2, 1, 1)
plot(fc, LW, 1.2)
title('Funkce f', FS, 16)

errfast = [];
odhad = [];
errgw = [];
NN = 2:2:120;
tic
for Npts = NN
  [s1,w1] = legpts(Npts);
  Ifast = w1*fc(s1);
  errfast = [errfast abs(Ifast-Ichebfun)];
end
toc
tic
for Npts = NN
  [s2,w2] = legendre_ek_compute(Npts);
  Igw = w2.'*f(s2);
  errgw = [errgw abs(Igw-Ichebfun)];
end
toc
subplot(2, 1, 2)
semilogy(NN,errfast,'.-',LW,1,MS,16), grid on
ylim([1e-18 1])
xlabel('počet uzlů',FS,12), ylabel('chyba výpočtu',FS,12)
title('Golub-Welsch vs Hale-Townsend',FS,16)
hold on
semilogy(NN, errgw,'.-',LW,1,MS,16)
legend('chyba HT','chyba GW')